package com.ibm.websphere.xs.sample.gettingstarted.server;

/**
 * COPYRIGHT LICENSE:  This information contains sample code provided in source code form. 
 * You may copy, modify, and distribute these sample programs in any form without payment to 
 * IBM for the purposes of developing, using, marketing or distributing application programs conforming 
 * to the application programming interface for the operating platform for which the sample code is written. 
 * Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE ON AN "AS IS" BASIS AND IBM 
 * DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR 
 * CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND ANY WARRANTY 
 * OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR 
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE SAMPLE SOURCE CODE.  
 *
 * This sample program is provided AS IS and may be used, executed, copied and
 * modified without royalty payment by customer (a) for its own instruction and
 * study, (b) in order to develop applications designed to run with an IBM
 * WebSphere product, either for customer's own internal use or for redistribution
 * by customer, as part of such an application, in customer's own products. 
 * 
 * 5724-X67, 5655-V66 (C) COPYRIGHT International Business Machines Corp. 2012
 * All Rights Reserved * Licensed Materials - Property of IBM
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;

import com.ibm.websphere.objectgrid.ObjectGrid;
import com.ibm.websphere.objectgrid.ObjectGridException;
import com.ibm.websphere.objectgrid.ObjectGridManager;
import com.ibm.websphere.objectgrid.ObjectGridManagerFactory;
import com.ibm.websphere.objectgrid.deployment.DeploymentPolicy;
import com.ibm.websphere.objectgrid.deployment.DeploymentPolicyFactory;
import com.ibm.websphere.objectgrid.deployment.MapSet;
import com.ibm.websphere.objectgrid.deployment.ObjectGridDeployment;
import com.ibm.websphere.objectgrid.server.CatalogServerProperties;
import com.ibm.websphere.objectgrid.server.Container;
import com.ibm.websphere.objectgrid.server.ServerFactory;
import com.ibm.websphere.objectgrid.server.ServerProperties;
import com.ibm.websphere.xs.sample.gettingstarted.Client;

/**
 * Create an eXtreme Scale server with a Catalog Server and Container Server.
 */
public class Server {

	/**
	 * The eXtreme Scale server singleton.  
	 */
	private static com.ibm.websphere.objectgrid.server.Server server = null;
	
	private static int numOfPartitions = 0;
	
    public static void main(String[] args) throws Exception {

        startCatalog();
        startEmbeddedContainer();

        // Here is a quick way to find out if your container servers are up and active, 
        // don't start your client until you are ready
        // Since our deployment.xml has 13 partitions, and only 1 sync replica, we know we should have only 13 shards available when starting up.
        // If we wait until we see the number of active shards is equal to the number of partitions, then we can continue running the client.
        awaitEmbeddedShardActivation();
        
        // Optionally start the interactive client in the same process.
        Client.main(new String[]{ServerFactory.getServerProperties().getCatalogServiceBootstrap()});
    }

    /**
     * Start an embedded server using the catalogServer.props file.
     */
    public static void startCatalog() throws ObjectGridException {

    	String props = System.getProperty("catalogServer.props", "config/catalogServer.props");
        File propsFile = new File(props);

    	ServerProperties svrProps = ServerFactory.getServerProperties();  	
        try {
            svrProps.load(new FileInputStream(propsFile));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        CatalogServerProperties catProps = ServerFactory.getCatalogProperties();
        try {
            catProps.load(new FileInputStream(propsFile));
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Start the server with the embedded catalog service
        server = ServerFactory.getInstance();
    }

    /**
     * Create a server and container in this process.  If a catalog service was already started, just
     * start a container using the server that was already started.
     */
    public static void startEmbeddedContainer() throws ObjectGridException, MalformedURLException {
    	
    	if(server == null) {
    		// Configure and start the server if not already started.
	    	String props = System.getProperty("containerServerProps", "config/containerServer.props");
	    	File propsFile = new File(props);
	    	ServerProperties conProps = ServerFactory.getServerProperties();
	    	try {
	    		conProps.load(new FileInputStream(propsFile));
	    	} catch (FileNotFoundException e) {
	    		e.printStackTrace();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    	}
	    	server = ServerFactory.getInstance();
	    }
    	
    	String objectgrid = System.getProperty("objectgridFile", "config/objectgrid.xml");
    	String deployment = System.getProperty("deploymentPolicyFile", "config/deployment.xml");
        
    	try {
    		File objectgridFile = new File(objectgrid);
    		File deploymentFile = new File(deployment);
        
        	URL ogXML = new URL("file:"+objectgridFile);
        	URL depXML = new URL("file:"+deploymentFile);
        	
        	// Start a container
            DeploymentPolicy dp = DeploymentPolicyFactory.createDeploymentPolicy(depXML, ogXML);
            server.createContainer(dp);
            
            // save the number of partitions the deployment xml has so that we can use that to wait for the partitions to activate
            ObjectGridDeployment ogd = dp.getObjectGridDeployment("Grid");
            MapSet mapSet = ogd.getMapSet("mapSet");
        	numOfPartitions = mapSet.getNumberOfPartitions();
    	}
    	catch (NullPointerException e) {
    		e.printStackTrace();
    	}
    	catch (MalformedURLException e) {
    		e.printStackTrace();
    	}
    }

    public static ObjectGrid createLocalObjectGrid(String objectGridXML, String gridName) throws ObjectGridException {
        ObjectGridManager ogm = ObjectGridManagerFactory.getObjectGridManager();
        ObjectGrid grid = ogm.getObjectGrid(gridName);
        if (grid == null) {

        	String objectgrid = System.getProperty("objectgridFile", "config/objectgrid.xml");
        	try {
        		File objectgridFile = new File(objectgrid);
            
            	URL ogXML = new URL("file:"+objectgridFile);
            
            	grid = ogm.createObjectGrid(gridName, ogXML);
        	} catch (Exception e) {
        		e.printStackTrace();
        	}
        }
        return grid;
    }
    
 /**
  * Try and see if the active shards are equal or greater to the number of partitions
  * If they are, then we know the container server is ready
  */
    public static void awaitEmbeddedShardActivation() throws InterruptedException {
    	boolean done = false;
    	int tries = 0;
        while (!done) {
        	server = ServerFactory.getInstance();
        	Collection<Container> containers = server.getContainers();
        
        	Iterator<Container> iterator = containers.iterator();
        	while (iterator.hasNext()) {
        		Container element = iterator.next();
        		if (element.getActiveShardCount() >= numOfPartitions) {
        			done = true;
         		}
        		Thread.sleep(5000);
            	tries++;
        		if (tries >= 12) { // timeout eventually
        			done = true;
        		}
        	}
    	}
    }
}
