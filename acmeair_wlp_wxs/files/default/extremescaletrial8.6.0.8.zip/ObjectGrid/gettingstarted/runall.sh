#!/bin/sh

#  This sample program is provided AS IS and may be used, executed, copied and modified
#  without royalty payment by customer
#  (a) for its own instruction and study,
#  (b) in order to develop applications designed to run with an IBM WebSphere product,
#  either for customer's own internal use or for redistribution by customer, as part of such an
#  application, in customer's own products.
#  Licensed Materials - Property of IBM
#  5724-J34 (C) COPYRIGHT International Business Machines Corp. 2012

# Setup our environment variables.
fileDir=`dirname ${0}`
. "$fileDir"/env.sh

# change to server directory 
cd server 

# Run the client
$JAVA_EXE -classpath "$SAMPLE_SERVER_CLASSPATH:$SAMPLE_CLIENT_CLASSPATH:$OG_CLASSPATH" "$JAVA_ENDORSED_DIRS" -Djava.util.logging.manager=com.ibm.ws.bootstrap.WsLogManager -Djava.util.logging.configureByServer=true com.ibm.websphere.xs.sample.gettingstarted.server.Server $CATALOGSERVER_HOST:$CATALOGSERVER_PORT $@

# go back to gettingstarted directory
cd ..
