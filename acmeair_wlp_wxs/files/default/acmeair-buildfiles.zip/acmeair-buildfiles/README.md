
# AcmeAir Buildfiles branch: master
Contains the src **and** the already built files form [acmeair/acmeair] (https://github.com/acmeair/acmeair) that were built using openjdk-7-jdk and the **WXS** data tier.
- acmeair incl. wxs on a single server setup

# AcmeAir Buildfiles branch: morphia-distributed
Contains the src **and** the already  built files form [acmeair/acmeair] (https://github.com/acmeair/acmeair) that were built using openjdk-7-jdk and the MongoDB (morphia) data tier.
- wlp/morphia contains the configuration file for single server setup (wlp+mongodb)
- wlp/morphia distributed contains the information for distributed setup: (wlp) + (mongodb)

#AcmeAir Sample Benchmrak application
Please refer to [acmeair/acmeair] (https://github.com/acmeair/acmeair) for information about the acmeair sample benchmark application.

