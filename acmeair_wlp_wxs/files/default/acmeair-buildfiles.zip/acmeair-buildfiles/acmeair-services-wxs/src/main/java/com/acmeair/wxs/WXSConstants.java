package com.acmeair.wxs;

public interface WXSConstants {

	public static final String JNDI_NAME = "wxs/acmeair";
	public static final String KEY = "wxs";
	public static final String KEY_DESCRIPTION = "eXtreme Scale";
	
}
